# NoteGenius AI — mobile-first first version

A browser-based, installable PWA prototype for organizing lecture transcripts and slide screenshots into handwritten-style UPSC/State PSC study notes.

## Working in this first version
- Mobile-first dashboard and notes library (saved in browser localStorage)
- YouTube URL field for source reference
- Transcript paste, word counter, sample lecture
- Multiple slide screenshot uploads with in-browser Tesseract.js OCR (English OCR model; results must be checked)
- Rule-based categorization into concepts, facts, explanations, exam strategy and lecture points
- Rapid-revision section, active-recall prompts, optional full transcript appendix
- PDF export with ruled-paper styling, page numbers, and original transcript/slide text appendix
- Copy note text, save/open/delete library items
- PWA manifest and service worker for home-screen installation on a supported HTTPS host

## Important current limitations
- The URL field does not automatically fetch YouTube captions, audio, or background slides. A URL alone is not enough in this browser-only version; paste a transcript and add screenshots.
- Note organization is rule-based, not a generative AI summary. The MCQ section produces active-recall prompts from source statements, not independently verified MCQs.
- OCR supports English in this prototype; verify all proper nouns, dates and numeric data. Auto-detect output language is a label/setting, not automatic translation.
- Third-party PDF/OCR libraries load from a CDN. First use requires internet. The app itself should be hosted over HTTPS for reliable PWA installation.
- The app does not guarantee complete extraction or factual accuracy. Keep the source appendix and review the completeness report.

## Use on Android without a computer
1. Download and extract this ZIP on your phone.
2. Host the folder using a GitHub repository and a static host such as Netlify or Cloudflare Pages. You can do these steps in Chrome on Android; choose the host's upload/deploy option if available.
3. Open the HTTPS site in Chrome, then use Chrome menu ⋮ → Add to Home screen / Install app.
4. For a standalone APK, a hosted PWA can be wrapped with a service such as PWABuilder, where supported. Review signing and permissions before installing. This project does not include a compiled APK.

## Local preview
Serve this folder from an HTTP server; opening index.html as a local file can disable service workers. Any static hosting service will work.

## Roadmap for full automatic processing
A production version needs a backend job pipeline: obtain permitted captions or user-provided audio/video, transcribe speech, sample frames at slide changes, OCR images, reconcile the two sources, flag gaps and contradictions, and render a PDF. Keep any AI provider key on the server, never in browser JavaScript. Only process content the user is authorized to access and follow YouTube/platform terms.
